# TechGuardinas Remote — Installation and User Guide

Version 2.0.0 · Self-hosted remote support on Linux, published across the MPLS network

---

## 1. What you are installing

TechGuardinas Remote lets technicians support users' Windows PCs from a web browser, entirely inside your network:

* **Attended support** — the user is at the PC. The technician generates a one-time 9-digit code; the user opens a web page, approves, runs a small support agent and clicks **Connect**; the user is asked again on screen before their desktop, a command prompt or files are opened, and can end the session at any time.
* **Unattended access** — an agent is installed on managed PCs (by GPO). Technicians connect to PCs an administrator has approved and assigned to them, after an MFA code.
* **Remote console in the browser** — screen with mouse and keyboard, multiple monitors, clipboard, file transfer, command terminal, chat, reboot with automatic reconnect.
* **Records** — every session is logged: who, which PC, how it was authorized, what was allowed, start/end, who ended it, outcome.

Everything runs on **one Linux server**: the portal, the remote-control engine (open-source MeshCentral), the relay, the database and the agent downloads. No Internet connection, cloud account or external service is used.

The server is reached by two internal names, for example:

| Name | Used by |
|---|---|
| `remote.techguardinas.local` | Portal: technicians, administrators, users joining a session |
| `mesh.remote.techguardinas.local` | Remote engine: the console inside the portal, and the agents on PCs |

Replace `techguardinas.local` with your internal domain throughout this guide.

---

## 2. Requirements

### Server
| Item | Minimum | Recommended (up to ~2,000 PCs) |
|---|---|---|
| CPU / RAM | 2 vCPU / 4 GB | 4 vCPU / 8 GB |
| Disk | 30 GB | 100 GB (more if session recording is enabled) |
| OS | Ubuntu 22.04/24.04 LTS or RHEL/Rocky/Alma 9 (64-bit) | same |
| Software | Docker Engine + Docker Compose plugin, `openssl`, `curl` | same |
| Network | Static IP reachable from every MPLS site on TCP 443 | same |

### Installing Docker

**Server has Internet or an internal Ubuntu mirror (easiest):**
```bash
sudo apt-get update
sudo apt-get install -y docker.io docker-compose-v2      # Ubuntu 22.04 / 24.04 packages
sudo systemctl enable --now docker
docker compose version                                  # must print a version
```

**Server has no Internet (Ubuntu):** on a connected Ubuntu machine of the **same version**, download the
packages, copy the folder to the server and install them there. `apt-get download` fetches only the named
packages (it has no `--resolve` option), so let apt collect everything into an empty folder instead:
```bash
# connected machine
mkdir -p ~/docker-debs && cd ~/docker-debs
sudo apt-get update
sudo apt-get install --download-only -y -o Dir::Cache::archives="$PWD" docker.io docker-compose-v2
ls *.deb
# copy ~/docker-debs to the server, then on the server:
cd docker-debs && sudo apt-get install -y ./*.deb && sudo systemctl enable --now docker
```
Run the download on a machine where Docker is **not** installed yet, otherwise apt skips packages it already has.

**RHEL / Rocky / Alma 9:** `dnf download` needs the plugin first: `sudo dnf install -y dnf-plugins-core`.
```bash
# connected machine
sudo dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
mkdir -p ~/docker-rpms && cd ~/docker-rpms
dnf download --resolve docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
# on the server:
cd docker-rpms && sudo dnf install -y ./*.rpm && sudo systemctl enable --now docker
```
Or use your organisation's internal package mirror.

### Client PCs
Windows 10/11 with Edge or Chrome. The **internal CA certificate** must be trusted (section 4.3).

---

## 3. Prepare the installation files

The zip contains the application but **not** the container images (about 2.5 GB). Create them once on any Linux machine that has Docker and Internet access (the "build machine"):

```bash
unzip techguardinas-remote-assist-setup-2.0.0.zip
cd techguardinas-remote-assist
./setup.sh build-images
```

This produces `images/techguardinas-remote-images.tar` and its checksum. Have it scanned by your security team, then copy the **whole `techguardinas-remote-assist` folder including `images/`** to the server (USB disk, internal file share, `scp`).

> If the server itself may reach your internal package/registry mirrors, you can skip this and run the install with `BUILD_ON_SERVER=1`.

---

## 4. Publish the server on the MPLS network

### 4.1 IP address and routing
Give the server a static IP in a data-centre VLAN that every MPLS site can route to (for example `10.20.30.40`). No NAT is needed. Agents and browsers always connect **to** the server; the server never connects to PCs.

### 4.2 Internal DNS
Create two A records pointing to the server IP, in a zone every site resolves.

On a Windows DNS server (PowerShell, as DNS administrator):
```powershell
Add-DnsServerResourceRecordA -ZoneName "techguardinas.local" -Name "remote"      -IPv4Address 10.20.30.40
Add-DnsServerResourceRecordA -ZoneName "techguardinas.local" -Name "mesh.remote" -IPv4Address 10.20.30.40
```
On BIND: `remote IN A 10.20.30.40` and `mesh.remote IN A 10.20.30.40`.

Check from a PC at a remote site: `nslookup remote.techguardinas.local` and `nslookup mesh.remote.techguardinas.local`.

### 4.3 Certificate (HTTPS)
Choose one:

* **Your organisation's CA (preferred)** — request a server certificate with both names as Subject Alternative Names. Before installing, place three files in `deploy/certs/` on the server: `fullchain.pem` (server certificate + intermediates), `privkey.pem` (its key), `ca.crt` (root CA). Your PCs probably trust this CA already.
* **A wildcard certificate you already own** (e.g. `*.gov.in` or `*.yourdept.gov.in`): a wildcard covers **one** name label only, so pick two names directly under it, e.g. `tgremote.gov.in` and `tgmesh.gov.in` (not `remote.inet.gov.in`). Copy the certificate, its private key and the intermediate certificate to the server, then:
  ```bash
  sudo ./setup.sh install-cert --cert wildcard.crt --key wildcard.key --chain intermediate.crt \
       --portal tgremote.gov.in --mesh tgmesh.gov.in
  ```
  **Have a `.pfx` / `.p12` file instead?** Use it directly (you are asked for its password):
  ```bash
  sudo ./setup.sh install-cert --pfx wildcard.pfx --portal tgremote.gov.in --mesh tgmesh.gov.in
  ```
  It checks that the key matches, the chain is complete, the certificate is valid and covers both names, then installs it, changes the names everywhere and restarts. For a public CA nothing has to be installed on PCs. Choose names that are not used by a real public site.
  **Internal DNS:** do **not** create a `gov.in` zone on your DNS server (it would hide every other gov.in site). Create one small zone per name instead, each with an A record for the zone itself:
  ```powershell
  Add-DnsServerPrimaryZone -Name "tgremote.gov.in" -ReplicationScope Forest
  Add-DnsServerResourceRecordA -ZoneName "tgremote.gov.in" -Name "@" -IPv4Address 10.20.30.40
  Add-DnsServerPrimaryZone -Name "tgmesh.gov.in" -ReplicationScope Forest
  Add-DnsServerResourceRecordA -ZoneName "tgmesh.gov.in" -Name "@" -IPv4Address 10.20.30.40
  ```
* **Let the installer create one** — if `deploy/certs/` is empty, `setup.sh` creates a dedicated "TechGuardinas Remote Internal CA" and the server certificate. You must then distribute the CA to every PC:
  * Group Policy Management → edit a GPO linked to all computers → *Computer Configuration → Policies → Windows Settings → Security Settings → Public Key Policies → Trusted Root Certification Authorities* → **Import** `TechGuardinas-Remote-Internal-CA.crt` (created next to `setup.sh`).
  * Single PC for testing: `certutil -addstore -f Root TechGuardinas-Remote-Internal-CA.crt` (administrator prompt).
  * **Script (does Windows store + Firefox in one go):** `deployment/gpo/Install-TechGuardinasCA.ps1 -CertPath <path to .crt>`. Use it as a GPO computer startup script for all PCs, or run it once as administrator on a test PC.
  * Firefox: enable policy *Certificates → ImportEnterpriseRoots*.
  * Keep `deploy/certs/ca.key` safe (copy it offline and remove it from the server once installation is complete).

### 4.4 Firewall rules
| From | To | Port | Why |
|---|---|---|---|
| All MPLS user and PC subnets | Server | **TCP 443** (or your `HTTPS_PORT`, e.g. 7443) | Portal, console, agents and relay — everything |
| All MPLS subnets | Server | TCP 80 (optional; **8008** if 80 is already used on the server) | Redirects to HTTPS only |
| Server | Domain controllers | TCP 636 | Only if AD login is enabled |
| Server, PCs | NTP server | UDP 123 | Correct time is required for MFA codes |

Nothing needs to be opened **towards** PCs: no RDP (3389), no SMB (445), no WinRM. The installer opens 443/80 on the server's own firewall (ufw/firewalld) if one is active. Full table: `deploy/NETWORK-PORTS.md`.

If the network team uses a proxy for web traffic, add both names to the proxy **bypass** list on PCs (browsers and agents must connect directly).

---

## 5. Install on the Linux server

```bash
cd techguardinas-remote-assist
sudo ./setup.sh install
```

You will be asked for:
1. **Portal host name** — e.g. `remote.techguardinas.local`
2. **Engine host name** — press Enter to accept `mesh.remote.techguardinas.local`
3. **Server IP** — detected automatically; confirm
4. **Administrator user name** — default `tgadmin`

**Ports.** By default HTTPS (everything) uses TCP 443 and the HTTP→HTTPS redirect uses TCP 80. If another program already uses one of them, the installer picks **7443** for HTTPS and/or **8008** for HTTP and tells you. To choose yourself: `sudo HTTPS_PORT=7443 HTTP_PORT=8008 ./setup.sh install`. With a non-standard port, users open the portal with the port in the address, e.g. `https://remote.techguardinas.local:7443`; agents and join links include it automatically.

**Change ports later:** `sudo ./setup.sh set-ports --https 9443 --http 8009` (either option alone is fine). It updates the settings, firewall and services and checks health. ⚠ Agents already installed on PCs have the HTTPS port built in: after changing the HTTPS port, download the group installers again and reinstall them (attended sessions are not affected).

The installer then checks the server, loads the images, writes `.env` with random secrets, creates or uses the certificate, generates the engine key, opens the firewall, starts all services and confirms that the portal and engine respond. The first administrator password is written to **`ADMIN-CREDENTIALS.txt`** (readable by root only) — note it, then delete the file.

Unattended example:
```bash
sudo ASSUME_YES=1 PORTAL_HOSTNAME=remote.techguardinas.local MESH_HOSTNAME=mesh.remote.techguardinas.local SERVER_IP=10.20.30.40 ./setup.sh install
```

The services restart automatically after a server reboot.

**Verify from a PC at another site:** open `https://remote.techguardinas.local` — you should see the TechGuardinas Remote sign-in page with a valid padlock (no certificate warning). Also open `https://mesh.remote.techguardinas.local` — a sign-in page must appear (it is never used directly; it proves the second name works).

---

## 6. First-time setup (administrator)

Sign in at `https://remote.techguardinas.local` with the bootstrap account.

1. **Settings → Configure authenticator.** Scan the QR code with an authenticator app (Microsoft Authenticator, Google Authenticator, FreeOTP — all work offline) and enter the 6-digit code.
2. **Users → Create local user** for each technician (role *TECHNICIAN*), auditor (*AUDITOR*) and further administrators. Passwords must be at least 12 characters. *Optional:* Settings → Active Directory/LDAPS, then *Provision AD user* and *Enable*.
3. **Groups & Agents → Create group**, e.g. `HQ-IT`, `Branch-Delhi`. Tick *Record sessions* if your policy requires recordings. Each group has its own agent installer.
4. **Deploy the agent** to the PCs of each group — see section 7.
5. **Device Approval** — PCs appear here as *PENDING* once their agent is running. Check the name/IP and click **Approve**. Unapproved PCs can never be accessed.
6. **Permissions** — choose a technician and a group (or a single device), tick what they may do (*Connect, File transfer, Terminal, Reboot*) and **Save**.
7. Ask every technician to enrol MFA (Settings) before their first unattended connection.

---

## 7. Deploying the agent to Windows PCs

1. **Groups & Agents → windows-x64** next to the group: downloads `TechGuardinas-Remote-Agent-<group>.exe`. It contains only the server's internal address and the group identity.
2. Record its hash: `Get-FileHash .\TechGuardinas-Remote-Agent-HQ-IT.exe -Algorithm SHA256`.
3. Copy it with `deployment/gpo/Install-TechGuardinasRemoteAgent.ps1` to `\\<domain>\NETLOGON\TechGuardinasRemote\`.
4. GPO (link to a pilot OU first): *Computer Configuration → Policies → Windows Settings → Scripts → Startup → PowerShell*:
   ```
   -NoProfile -ExecutionPolicy Bypass -File \\<domain>\NETLOGON\TechGuardinasRemote\Install-TechGuardinasRemoteAgent.ps1 -InstallerPath \\<domain>\NETLOGON\TechGuardinasRemote\TechGuardinas-Remote-Agent-HQ-IT.exe -Sha256 <hash>
   ```
5. Reboot a pilot PC; it appears under **Device Approval**. Log: `C:\ProgramData\TechGuardinasRemote\install.log`.
6. Single PC by hand (administrator prompt): `TechGuardinas-Remote-Agent-HQ-IT.exe -fullinstall`.

Removal: `Uninstall-TechGuardinasRemoteAgent.ps1 -InstallerPath <same exe>`, then *Revoke* the device in the portal.

---

## 8. Technician guide

### 8.1 Attended support (user is at the PC)
1. **Start Remote Support → Generate session code.** A 9-digit code and a link appear (valid for 10 minutes, single use).
2. Give the user the **code** (phone) or the **link** (internal chat/e-mail).
3. Watch the progress list: *user approved → agent connecting → Connected: PC name*.
4. Click **Open remote console**. The user sees *"<your name> requesting remote desktop access. Grant access?"* and clicks **Yes**.
5. Work in the console (8.3). Terminal and Files each ask the user again.
6. Click **End Session** and type the outcome (e.g. *Resolved — printer driver reinstalled*).

### 8.2 Unattended access (managed PC)
1. **Unattended Access** lists only the PCs you are permitted to use, with Online/Offline status.
2. Click **Connect** next to an online PC and enter your current **6-digit MFA code**.
3. The console opens. A connection bar on the PC shows that a session is in progress.
4. **End Session** when finished, with an outcome note.

### 8.3 The remote console
| Control | What it does |
|---|---|
| **Remote Desktop** | Click *Connect* inside the view. Move the mouse over the screen to type into it. Toolbar below: Ctrl+Alt+Del, clipboard, display selection (multiple monitors), full screen. |
| **Terminal** | Command prompt on the remote PC (if permitted). |
| **Files** | Browse, upload and download files (if permitted). |
| **Device Events** | The engine's event list for the PC. |
| **Chat** | Opens a chat window with the user. |
| **Reboot** | Restarts the PC (if permitted). Unattended: the console shows *Device offline* and reconnects automatically. Attended: the session ends (the user must reconnect). |
| **End Session** | Ends access immediately and records the outcome. |

The top bar shows the PC, mode, session code, online status, elapsed time and the session's end time (sessions are limited to 2 hours by default; the console signs out after 15 minutes of inactivity).

---

## 9. Remote user guide (print and share)

> **Getting help from TechGuardinas IT**
> 1. The technician tells you a **9-digit code** or sends a link.
> 2. Open **https://remote.techguardinas.local/join** and type the code (or click the link).
> 3. Check the technician's name, type your name, tick **I authorize this remote support session**, click **Approve**.
> 4. Click **Download**, open the downloaded file and click **Connect**. Nothing is installed.
> 5. When the technician wants to see your screen, a box asks **Grant access?** — click **Yes**. You will be asked again for a command prompt or files.
> 6. To stop at any time: click **End session** on the web page, or close the support agent window, or click **Disconnect** on the bar at the top of your screen.
> When the session ends the technician has no further access. Close the support agent window.

---

## 10. Auditor guide
* **Sessions → All technicians** lists every session; **Details** shows the full record: technician, PC, how access was authorized (user consent or permission + MFA), the user's on-screen answers, allowed features, times, who ended it and why, outcome, the audit trail and the engine's own events.
* **Audit Log** lists every sign-in, failed sign-in, permission change, device approval, session step and denial, searchable by user or detail.
* Session recordings (if enabled) are kept on the server; see `deploy/DEPLOYMENT.md`.

---

## 11. Operating the server

All commands run in the `techguardinas-remote-assist` folder on the server.

| Task | Command |
|---|---|
| Status and health | `sudo ./setup.sh status` |
| Stop / start / restart | `sudo ./setup.sh stop` · `start` · `restart` |
| Logs (all, or one service) | `sudo ./setup.sh logs` · `sudo ./setup.sh logs web` |
| Backup (database + engine data) | `sudo ./setup.sh backup` (to `/var/backups/techguardinas-remote`; set `BACKUP_DIR=` to change) |
| Restore database | `sudo ./deploy/restore-postgres.sh /var/backups/techguardinas-remote/portal-<date>.dump` |
| Print the CA certificate | `./setup.sh export-ca` |
| Diagnose agents not connecting / engine problems | `sudo ./setup.sh doctor` |
| Repair portal ↔ engine link ("Remote engine error … noauth" / 502) | `sudo ./setup.sh repair-engine` |
| Install a new/real certificate (and optionally new names) | `sudo ./setup.sh install-cert --pfx c.pfx` or `--cert c.crt --key c.key [--chain i.crt]`, plus `[--portal name --mesh name]` |
| Change host names | `sudo ./setup.sh set-hosts --portal <name> --mesh <name>` (reinstall agents afterwards) |
| Change ports | `sudo ./setup.sh set-ports --https <port> --http <port>` (reinstall agents after an HTTPS port change) |
| Reset the bootstrap admin password | `sudo ./setup.sh reset-admin-password` |
| Emergency: stop all remote access | `sudo docker compose stop meshcentral` |
| Remove (keeps data unless you type PURGE) | `sudo ./setup.sh uninstall` |

Schedule a nightly backup: `echo '30 1 * * * root cd /opt/techguardinas-remote-assist && ./setup.sh backup' | sudo tee /etc/cron.d/techguardinas-remote` (adjust the path), and copy the backups off the server.

**Policy settings** (session length, code validity, MFA, clipboard, consent, recording) are in `.env`; after editing run `sudo ./setup.sh restart`. They are explained in `deploy/DEPLOYMENT.md`.

**Updating:** build new images on the build machine (`./setup.sh build-images` with the new version), back up, copy `images/` to the server, `sudo docker load -i images/techguardinas-remote-images.tar`, `sudo ./setup.sh restart`.

---

## 12. Troubleshooting

| Symptom | Check |
|---|---|
| "Remote engine error: MeshCentral rejected the portal credentials (noauth)" | Run `sudo ./setup.sh repair-engine` in the install folder (re-creates the engine service account and restarts the engine; prints diagnostics if it still fails). |
| "Request failed (400)" / "Bad Request (400)" | You opened the portal by IP or by a name that was not configured. Use the portal name chosen at install (with `:port` if not 443); add the DNS records (4.2), or for a quick test a hosts-file entry on the PC: `<server IP>  <portal name>  mesh.<portal name>`. |
| Browser shows a certificate warning | The CA is not trusted on that PC (4.3), or you opened the IP instead of the host name. |
| Page does not open from a remote site | DNS record (`nslookup`), routing/firewall to TCP 443, proxy bypass for both names. |
| Console area stays blank | `mesh.remote…` blocked or not resolving from the technician's PC. |
| Attended: user clicked **Connect** but the session stays *Waiting* | The PC cannot reach the engine name. On the PC: `Resolve-DnsName mesh.<portal name>` and `Test-NetConnection mesh.<portal name> -Port <HTTPS port>` must both work (add the `mesh.` DNS record / hosts entry). On the server: `sudo ./setup.sh doctor`. |
| PC never appears in Device Approval | On the PC: service *TechGuardinasRemoteAgent* running? `Test-NetConnection mesh.remote.techguardinas.local -Port 443`. |
| "MFA is required" / "Invalid MFA code" | Enrol in Settings; check the phone's and server's clock (NTP). |
| "You are not authorized for this device" | Device not approved, or no permission for the technician (Permissions page). |
| Attended code "not valid or has expired" | Codes are single-use and valid 10 minutes; generate a new one. |
| Session ends by itself | Two-hour limit, the device was un-approved, the technician account was disabled, or the user ended it — see the session record. |
| Anything else | `sudo ./setup.sh status` and `sudo ./setup.sh logs web worker meshcentral nginx` |

---

## 13. Before going live

The system has been tested end to end on Linux test PCs, including a fully network-isolated run and a run of this installer's Docker deployment. **The two-Windows-PC acceptance test has not yet been performed.** Complete `docs/ACCEPTANCE-TEST.md` §2 on a pilot OU before rolling the agent out widely, and read `docs/STATUS-AND-LIMITATIONS.md` (notably: clipboard policy is global; the attended agent window must be closed by the user after the session; Windows-specific behaviour still to be confirmed).
